/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actividad;

import java.util.ArrayList;

/**
 *
 * @author luis0
 */
public class Estadisticas {

    private byte tm, th, tc, td, ts, tv, total, mad, med;
    private float ph, pm;
    private ArrayList<Persona> Invitados=new ArrayList();

    public void añadirPersona() {
        Persona aux = new Persona();
        aux.setNombre(Tools.validName("Dame tu nombre"));
        aux.setEstadoc(Tools.Estado());
        totalEstado(aux.getEstadoc());
        aux.setSexo(Tools.Sexo());
        totalSexo(aux.getSexo());
        aux.setEdad(Tools.validEdad("Ingrese la edad"));
        totalEdad(aux.getEdad());
        total+=1;
        Invitados.add(aux);
        
        
    }
    public void totalEstado(String a){
        char b=a.charAt(0);
        switch (b) {
            case 'C':tc++;
                break;
            case 'D':td++;break;
            case 'S':ts++;break;
            case 'V':tv++;break;
            default:
                throw new AssertionError();
        }
        
    
    
    }
    public void totalSexo(String a){
        char b=a.charAt(0);
        switch (b) {
            case 'M':tm++;
                break;
            case 'H':th++;break;
            
            default:
                throw new AssertionError();
        }
        
    
    
    }
    
    public void totalEdad(byte e){
        if(e>=18){mad+=1;}else{med+=1;}
    
    }
    public void Porcentajes(){
        pm=(tm*100)/total;
        
        ph=100-pm;
    
    }

    public byte getTm() {
        return tm;
    }

    public byte getTh() {
        return th;
    }

    public byte getTc() {
        return tc;
    }

    public byte getTd() {
        return td;
    }

    public byte getTs() {
        return ts;
    }

    public byte getTv() {
        return tv;
    }

    public byte getTotal() {
        return total;
    }

    public byte getMad() {
        return mad;
    }

    public byte getMed() {
        return med;
    }

    public float getPh() {
        return ph;
    }

    public float getPm() {
        return pm;
    }
    
    

    
    
    
}
