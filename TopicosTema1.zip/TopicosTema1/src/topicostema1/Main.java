
package topicostema1;
import GUI.*;
import Mas.*;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUIALUMNO A= new GUIALUMNO();
        
        
        // TODO code application logic here
    }
    static void menuAlumno(){
        Scanner Luis=new Scanner(System.in);
        
        ListaAlumnos obj = new ListaAlumnos();
        byte op=0;
        do{
            op=Byte.parseByte(JOptionPane.showInputDialog(null,""
                    + "1.-Agregar alumno\n"
                    + "2.-Ver datos\n"
                    + "3.-Eleminar uno\n"
                    + "4.-Eliminar todos\n"
                    + "5.-Salir"));
            
            switch (op) {
                    
                case 1:obj.añadir(obj.crearAlumno());
                        
                    
                    break;
                case 2: 
                    obj.MostrarAlumnos();
                    break;
                    
                case 3:
                       int a=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingresa la posición", "Elim", JOptionPane.ERROR_MESSAGE));
                       obj.Eliminar(a);
                    break;
                case 4: 
                        obj.ElimarTodos();
                    
                    break;
                default:
                    System.out.println("Error, opción no definida");
            }
            
        
        }while(op!=5);
    
    }
    
}
