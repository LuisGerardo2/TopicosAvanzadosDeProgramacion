/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;
import java.awt.FlowLayout;
import javax.swing.*;
/**
 *
 * @author luis0
 */
public class GUI5 extends JFrame{
    
    public GUI5(){
    super("Ventana con herencia");
    getContentPane().setLayout(new FlowLayout());
    JButton boton=new JButton("Aceptar");
    JLabel eti=new JLabel("Dato");
    JTextField campo=new JTextField(10);
    JCheckBox ch=new JCheckBox("check box");
    
    
    getContentPane().add(boton);
    getContentPane().add(eti);
    getContentPane().add(campo);
    getContentPane().add(ch);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    setLocationRelativeTo(null);
    setVisible(true);
    
    
            
            }
    
}
