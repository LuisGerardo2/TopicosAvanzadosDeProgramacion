/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actividad;

import javax.swing.JOptionPane;

/**
 *
 * @author luis0
 */
public class Actividad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int opc=0;
        Estadisticas a=new Estadisticas();
        do{
            opc=Integer.parseInt(JOptionPane.showInputDialog(null,"1.-Añador"
                    + "\n2.-Salir","Menú",
                    JOptionPane.INFORMATION_MESSAGE));
            switch (opc) {
                case 1: a.añadirPersona();
                    break;
                case 2: JOptionPane.showMessageDialog(null, "Adioooos","Despedida",JOptionPane.OK_OPTION);
                    break;    
                default:
                    JOptionPane.showMessageDialog(null, "Opcion no valida","Error",JOptionPane.ERROR_MESSAGE);

            }}while(opc!=2);
        a.Porcentajes();
        System.out.println("A la fiesta asistieron "+a.getTotal()+" personas de las cuales: \n"+"La cantidad de mujeres es: "+a.getTm()
                +"\nLa cantidad de hombres es: "+a.getTh()
                +"\nLa cantidad de gente casada es: "+a.getTc()
                +"\nLa cantidad de gente soltera es: "+a.getTs()
                +"\nLa cantidad de gente divorciada es: "+a.getTd()
                +"\nLa cantidad de gente viuda es: "+a.getTv()
                +"\nPersonas mayores de edad son: "+a.getMad()
                +"\nPersonas menores de edad son: "+a.getMed()
                +"\nPorcentaje de hombres: "+a.getPh()
                
                +"\nPorcentaje mujeres: "+a.getPm()
                
        );
        
    }
    
}
