
package GUI;

import javax.swing.JFrame;

public class GUI2 {
    public GUI2(){
        JFrame frame=new JFrame("Sin herencia");
        frame.setSize(370,450);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(true);
        frame.setVisible(true);
    
    }
    
    
}
