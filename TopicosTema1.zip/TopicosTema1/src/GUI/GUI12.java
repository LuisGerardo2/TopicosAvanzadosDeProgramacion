package GUI;

import Mas.ListaAlumnos;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.*;

public class GUI12 extends JFrame implements ActionListener {

    private JTextField nmctrl;
    private JTextField sem;
    private JTextField nombre;
    private JTextField edad;
    private JLabel a;
    private JLabel n2;
    private JLabel n3;
    private JLabel n4;
    private JButton b1;
    private JButton b2;
    private JButton b3;
    private ListaAlumnos lista; 
    private Container contenedor;

    private JList listaNombres;
    private DefaultListModel modelo;
    private JScrollPane scrollLista;

    private JPanel uno = new JPanel();
    private JPanel dos = new JPanel();

    public GUI12() {
        setLayout(null);

        GridLayout tamaño = new GridLayout(4, 2);
        GridLayout tamaño2 = new GridLayout(1, 3);

        uno.setLayout(tamaño);
        dos.setLayout(tamaño2);

        setTitle("Registro");
        setSize(300, 350);
        setResizable(false);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a = new JLabel("No. Crtl");
         

        nmctrl = new JTextField("");
        nmctrl.setBounds(1, 1, 10, 10);
        
        n2 = new JLabel("Nombre");
        

        nombre = new JTextField("       ");
        nombre.setBounds(1, 1, 10, 40);

        n3 = new JLabel("Semestre");

        sem = new JTextField("        ");
        sem.setBounds(1, 1, 10, 40);

        n4 = new JLabel("Edad");

        edad = new JTextField("       ");
        edad.setBounds(1, 1, 10, 40);

        uno.add(a);
        uno.add(nmctrl);
        uno.add(n2);
        uno.add(nombre);
        uno.add(n3);
        uno.add(sem);
        uno.add(n4);
        uno.add(edad);

        b1 = new JButton("Añadadir");
        b1.addActionListener((e)->{
            nombre.getText();
            
            
        
        });
        
        dos.add(b1);
        b2 = new JButton("Eliminar");

        b2.addActionListener((e) -> {
            JOptionPane.showMessageDialog(null, "Adioooos", "Salida", JOptionPane.INFORMATION_MESSAGE);
            this.dispose();

        }
        );

        dos.add(b2);
        b3 = new JButton("Eliminar todos");
        b3.addActionListener((e) -> {
            JOptionPane.showMessageDialog(null, "Buenas tardes", "Mnesjae", JOptionPane.INFORMATION_MESSAGE);

        });
        dos.add(b3);
        uno.setBounds(1, 1, 300, 270);
        dos.setBounds(1, 272, 300, 40);
        add(uno);
        add(dos);
        setVisible(true);
}
    @Override
    public void actionPerformed(ActionEvent e) {
        }
}
        

    

