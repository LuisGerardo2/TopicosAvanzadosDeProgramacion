/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mas;


public class Alumnos {
    private String numCtrl;
    private String nombre;
    private byte semestre;
    private byte edad;

    Alumnos(String numCtrl, String nombre, byte semestre, byte edad) {
        this.numCtrl = numCtrl;
        this.nombre = nombre;
        this.semestre = semestre;
        this.edad = edad;
    }
    public Alumnos(){}

    public void setSemestre(byte semestre) {
        this.semestre = semestre;
    }
    
    
    public void setNumCtrl(String numCtrl) {
        this.numCtrl = numCtrl;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(byte edad) {
        this.edad = edad;
    }

    public String getNumCtrl() {
        return numCtrl;
    }

    public String getNombre() {
        return nombre;
    }

    public byte getSemestre() {
        return semestre;
    }

    public byte getEdad() {
        return edad;
    }

    @Override
    public String toString() {
        return "Alumnos{" + "numCtrl=" + numCtrl + ", nombre=" + nombre + ", semestre=" + semestre + ", edad=" + edad + '}';
    }
    
    
}
