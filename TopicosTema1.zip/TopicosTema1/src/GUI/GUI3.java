/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.awt.Container;
import javax.swing.*;

/**
 *
 * @author luis0
 */
public class GUI3 extends JFrame{
    private Container panel;
    private JButton miboton;
    
    public GUI3(){
    super("Ventana/herencia");
    miboton=new JButton("Aceptar");
    panel=getContentPane();
    panel.add(miboton);
    setSize(200,200);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setResizable(false);
    setVisible(true);
    }
    
    
}
