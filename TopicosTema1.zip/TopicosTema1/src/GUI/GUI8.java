/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
/**
 *
 * @author luis0
 */
public class GUI8 extends JFrame implements ActionListener{

   private JTextField textField;
   private JButton boton;
   private JLabel label;
   
   public GUI8(){
       super("Gui8: Activación oyente");
       setLayout(null);
       setSize(300,150);
       setResizable(false);
       setDefaultCloseOperation(EXIT_ON_CLOSE);
       
       label=new JLabel("Nombre");
       label.setBounds(10,10,100,30);
       add(label);
       textField=new JTextField();
       textField.setBounds(80,10,150,30);
       add(textField);
       boton=new JButton("Saludar");
       boton.setBounds(10,80,100,30);
       boton.addActionListener(this);
       add(boton);
       setVisible(true);
       
   }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==boton){
        JOptionPane.showMessageDialog(null,"Hola "+textField.getText()+" Felicidadees!!" ,"Saludo",JOptionPane.INFORMATION_MESSAGE);
        }
        
         }
    
    
}
