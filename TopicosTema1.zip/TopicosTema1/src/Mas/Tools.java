/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mas;

import javax.swing.JOptionPane;

/**
 *
 * @author luis0
 */
public class Tools {
    public static String validName(String msj){
       String cad;
       boolean band;
       do{
           cad=JOptionPane.showInputDialog(null,msj,"Lectura String ",JOptionPane.QUESTION_MESSAGE);
           band=(cad!=null && cad.matches("([a-zA-Z]|\\s)+"));
           if(band) return cad;
           else
               System.out.println(cad+" contiene caracteres no validos");
       }while(band);
       return cad;
   }
   public static String validCtrl(String ctrl){
       String num;
       boolean band=false;
       do{
           num=JOptionPane.showInputDialog(null,ctrl,"Lectura String ",JOptionPane.QUESTION_MESSAGE);
       num=num.trim();band= num!=null && num.matches("[0-9]{8}");
       if(!band){
           System.out.println("El numero de control debe contener 8 digitos entre 0 y 9");
       }
       }while(!band);
       
       return num;
       
   }
   
   public static byte Semestre(){
       String valores[]={"1","2", "3","4","5","6","7","8","9","10","11","12"};
       return Byte.parseByte((String) JOptionPane.showInputDialog(null,"Selecciona","Semestre",JOptionPane.QUESTION_MESSAGE,null,valores,valores[0]));
    }
   public static byte validEdad(String msj){
       byte edad=0;
       boolean band=false;
       do{
         try{
             edad=Byte.parseByte(JOptionPane.showInputDialog(null,msj,"Edad ",JOptionPane.QUESTION_MESSAGE));
             band=(edad>=17 && edad<=60);
             if(band) return edad;
             else JOptionPane.showMessageDialog(null,"Lo sentimos, la edad debe ser un número entre 17 y 60","Error",JOptionPane.ERROR_MESSAGE);
         }catch(Exception a){
             
         }
       }while(!band);
       return edad;
   }
   
}
