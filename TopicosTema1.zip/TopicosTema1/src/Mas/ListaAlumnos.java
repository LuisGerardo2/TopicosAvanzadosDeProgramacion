
package Mas;

import java.util.ArrayList;

public class ListaAlumnos {
    private ArrayList<Alumnos> Lista;
    
    public ListaAlumnos(){
        Lista=new<Alumnos> ArrayList();
        
    
    }
    
    public void añadir(Alumnos a){
        Lista.add(a);
    
    }
    
    public void Eliminar(int pos){
        Lista.remove(pos);
    }
    
    public void ElimarTodos(){
        Lista.removeAll(Lista);
    }
    public void MostrarAlumnos(){
        int count=0;
        for(Alumnos a:Lista){
            System.out.println(a.toString()+"Posición: "+count);
            count++;
        }
    
    }
    public Alumnos crearAlumno() {
        Alumnos aux = new Alumnos();
        aux.setNumCtrl(Tools.validCtrl("Dame tu numero de control"));
        aux.setNombre(Tools.validName("Dame tu nombre"));
        aux.setSemestre(Tools.Semestre());
        aux.setEdad(Tools.validEdad("Ingrese la edad"));
        return aux;
    }

    
    
}
