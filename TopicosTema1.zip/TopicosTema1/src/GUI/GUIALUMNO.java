/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;
import Mas.Alumnos;

import Mas.ListaAlumnos;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;



/**
 *
 * @author luis0
 */
public class GUIALUMNO extends JFrame implements ActionListener{
    
    private ListaAlumnos lista; 
    private Container contenedor;
    private JTextField campoNumero;
    private JTextField campoSemestre;
    private JTextField campoNombre;
    private JTextField campoEdad;
    private JTextField campoTotal;
    private JLabel numCtrl;
    private JLabel semestre;
    private JLabel nombre;
    private JLabel edad;
    private JLabel total;
    private JButton añadir;
    private JButton eliminar;
    private JButton EliminarTodo;
    private JList listaNombres;
    private DefaultListModel modelo;
    private JScrollPane scrollLista;
    
    public GUIALUMNO(){
        lista = new ListaAlumnos(); // Crea la lista de alumnos
        inicio();
        setTitle("Captura datos ");
        setSize(300, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);

    
    }
    private void inicio() {
        contenedor = getContentPane();
        contenedor.setLayout(null);
        numCtrl = new JLabel();
        numCtrl.setText("Num.Control:");
        numCtrl.setBounds(10, 10, 100, 20);
        campoNumero = new JTextField();
        campoNumero.setBounds(100, 10, 150, 20);
        semestre = new JLabel();
        semestre.setText("Semestre:");
        semestre.setBounds(10, 30, 100, 20);
        campoSemestre = new JTextField();
        campoSemestre.setBounds(100, 30, 150, 20);
        
        nombre = new JLabel();
        nombre.setText("Nombre:");
        nombre.setBounds(10, 50, 100, 20);
        campoNombre = new JTextField();
        campoNombre.setBounds(100, 50, 150, 20);
        
        edad = new JLabel();
        edad.setText("Edad:");
        edad.setBounds(10, 70, 100, 20);
        campoEdad = new JTextField();
        campoEdad.setBounds(100, 70, 150, 20);
        
            total=new JLabel();
            total.setText("No.Registro:");
            total.setBounds(20, 256, 135, 23);
            campoTotal=new JTextField();
            campoTotal.setBounds(20, 256, 135, 23);
        
        añadir = new JButton();
        añadir.setText("Alta");
        añadir.setBounds(10, 280, 80, 23); 
        añadir.addActionListener(this);
        // Establece el botón Eliminar Alumno
        eliminar= new JButton();
        eliminar.setText("Eliminar");
        eliminar.setBounds(100, 280, 80, 23); 
        eliminar.addActionListener(this);
        // Establece el botón Borrar list
        EliminarTodo= new JButton();
        EliminarTodo.setText("Limpia lista");
        EliminarTodo.setBounds(190, 280, 120, 23); 
        EliminarTodo.addActionListener(this);
        
        listaNombres = new JList();
        listaNombres.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        modelo = new DefaultListModel();
        // Establece una barra de desplazamiento vertical
        scrollLista = new JScrollPane();
        scrollLista.setBounds(10, 150 ,280, 100);
        // Asocia la barra de desplazamiento vertical a la lista de personas
        scrollLista.setViewportView(listaNombres);
        
        contenedor.add(numCtrl);
            contenedor.add(campoNumero);
            contenedor.add(nombre);
            contenedor.add(campoNombre);
            contenedor.add(semestre);
            contenedor.add(campoSemestre);
            contenedor.add(edad);
            contenedor.add(campoEdad);
        contenedor.add(total);
        contenedor.add(añadir);
        contenedor.add(eliminar);
        contenedor.add(EliminarTodo);
        contenedor.add(scrollLista);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == añadir) { 
            añadirAlumno(); 
        }
        if (evento.getSource() == eliminar) {
            
            eliminarAlumno(listaNombres.getSelectedIndex());
        }
        if (evento.getSource() == EliminarTodo) {
           
            EliminarTodo(); 
        }

    }

    private void añadirAlumno() {
        
        Alumnos p = new Alumnos();
        p.setNombre(campoNombre.getText());
        p.setNumCtrl(campoNumero.getText());
        p.setSemestre(Byte.parseByte(campoSemestre.getText()));
        p.setEdad(Byte.parseByte(campoEdad.getText()));
        lista.añadir(p);
        
        String cad = campoNombre.getText() + " " + campoNumero.getText() + " "
                + campoSemestre.getText() + " " + campoEdad.getText();
        modelo.addElement(cad);
        
        listaNombres.setModel(modelo);
        int x = modelo.getSize();
        total.setText("No.Registro:" + x);
        campoNumero.setText("");
        campoNombre.setText("");
        campoSemestre.setText("");
        campoEdad.setText("");
        campoTotal.setText("");
    }

    private void eliminarAlumno(int indice) {
        if (indice >= 0) { 
            modelo.removeElementAt(indice);
            
            lista.Eliminar(indice);
            int x = modelo.getSize();
            total.setText("No.Registro:" + x);
        } else {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento");
        }
    }

    private void EliminarTodo() {
        lista.ElimarTodos();
        modelo.clear(); 
        int x = modelo.getSize();
        total.setText("No.Registro:" + x);
    }

    
    


}
