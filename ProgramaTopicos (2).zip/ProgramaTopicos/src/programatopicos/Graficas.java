/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programatopicos;
 import java.awt.Dimension;

import org.jfree.chart.ChartPanel;

import org.jfree.chart.JFreeChart;

import javax.swing.JFrame;
/**
 *
 * @author luis0
 */
public class Graficas extends JFrame {
   
   
    
    public static void panelJframe(JFreeChart grafica)
{ 
//   Se crea un Panel para almacenar la grafica generada llamada grafica_Barras, (ChartPanel es el equivalente a JPanel en ambiente grafico)
        ChartPanel panel= new ChartPanel(grafica);
    
        panel.setMouseWheelEnabled(true);
        panel.setPreferredSize(new Dimension(500,300));
 //Creamos una ventana para presentar la grafica que esta almacenada en el panel
        JFrame ventana = new JFrame("Grafica"); // titulo del frame
        ventana.setVisible(true);
        ventana.setSize(800, 600); // tamaño del Jframe
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.add(panel);// se agrega al Jframe el panel(Grafico)
 
}
    
    
    

}