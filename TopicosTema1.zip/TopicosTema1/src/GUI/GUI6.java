/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;
import java.awt.GridLayout;
import javax.swing.*;
/**
 *
 * @author luis0
 */
public class GUI6 extends JFrame {
    public GUI6(){
        super("Ventana con herencias");
        getContentPane().setLayout(new GridLayout(4,3,5,5));
        for (int i = 1; i <= 12; i++) 
            add(new JButton(Integer.toString(i)));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
            
        
        
    
    
    }
    
}
